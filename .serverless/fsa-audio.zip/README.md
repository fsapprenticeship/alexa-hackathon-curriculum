# alexa-hackathon-curriculum
Creating an audio companion to the FSA Experience System, setting reminders for students in order to achieve excellence.
